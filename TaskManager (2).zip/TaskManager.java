import java.util.ArrayList;
import java.util.InputMismatchException;
import java.util.List;
import java.util.Scanner;

class TeamMember {
    private String name;
    private String teamId;

    public TeamMember(String name, String teamId) {
        this.name = name;
        this.teamId = teamId;
    }

    public String getName() {
        return name;
    }

    public String getTeamId() {
        return teamId;
    }
}

class Task {
    private String name;
    private String description;
    private String teamId;

    public Task(String name, String description) {
        this.name = name;
        this.description = description;
    }

    public String getName() {
        return name;
    }

    public String getDescription() {
        return description;
    }

    public String getTeamId() {
        return teamId;
    }

    public void setTeamId(String teamId) {
        this.teamId = teamId;
    }
}

public class TaskManager {
    private List<Task> tasks;
    private List<TeamMember> teamMembers;

    public TaskManager() {
        tasks = new ArrayList<>();
        teamMembers = new ArrayList<>();
    }

    public void addTask(Task task) {
        if (isTaskNameUnique(task.getName())) {
            tasks.add(task);
            System.out.println("Task added successfully!");
        } else {
            System.out.println("Task with the same name already exists. Please choose a different name.");
        }
    }

    public void removeTask(String taskName) {
        tasks.removeIf(task -> task.getName().equalsIgnoreCase(taskName));
        System.out.println("Task removed successfully!");
    }

    public void displayTasks() {
        if (tasks.isEmpty()) {
            System.out.println("No tasks found.");
        } else {
            System.out.println("\n+-------------------+-------------------+-------------------+");
            System.out.printf("| %-17s | %-17s | %-17s |%n", "Task Name", "Assigned Team ID", "Member name");
            System.out.println("+-------------------+-------------------+-------------------+");

            for (Task task : tasks) {
                if (task.getTeamId() == null) {
                    System.out.printf("| %-17s | %-17s | %-17s |%n", task.getName(), "Not Assigned", "Not Assigned");
                    System.out.println("+-------------------+-------------------+-------------------+");
                } else {
                    String teamName = getTeamNameById(task.getTeamId());
                    List<String> teamMemberNames = getTeamMemberNamesById(task.getTeamId());

                    for (String teamMemberName : teamMemberNames) {
                        System.out.printf("| %-17s | %-17s | %-17s |%n", task.getName(), teamName, teamMemberName);
                        System.out.println("+-------------------+-------------------+-------------------+");
                    }
                }
            }
        }
    }

    public void addTeam(String teamNameOrId, int numMembers) {
        if (isTeamNameOrIdUnique(teamNameOrId)) {
            for (int i = 1; i <= numMembers; i++) {
                System.out.print("Enter team member name " + ": ");
                Scanner scanner = new Scanner(System.in);
                String teamMemberName = scanner.nextLine();
                if (isTeamMemberNameUnique(teamMemberName)) {
                    teamMembers.add(new TeamMember(teamMemberName, teamNameOrId));
                } else {
                    System.out.println("This name is already been taken. Please choose a different name.");
                    i--;
                }
            }
            System.out.println("Team added successfully!");
        } else {
            System.out.println("This name or ID is already been taken. Please choose a different name or ID.");
        }
    }

    public void displayTeamMembers() {
        if (teamMembers.isEmpty()) {
            System.out.println("No team members found.");
        } else {
            System.out.println("\n+-------------------+-------------------+");
            System.out.printf("| %-17s | %-17s |%n", "Team Member Name", "Team ID");
            System.out.println("+-------------------+-------------------+");
            for (TeamMember member : teamMembers) {
                System.out.printf("| %-17s | %-17s |%n", member.getName(), member.getTeamId());
                System.out.println("+-------------------+-------------------+");
            }
        }
    }

    public void assignTask(String taskName, String teamId) {
        Task task = findTaskByName(taskName);
        if (task != null) {
            if (isTeamIdValid(teamId)) {
                displayTeamMembersWithIds();
                System.out.print("Please enter ID to assign project manager: ");
                Scanner scanner = new Scanner(System.in);
                String memberId = scanner.nextLine();
                if (isMemberIdValid(memberId, teamId)) {
                    task.setTeamId(teamId);
                    System.out.println("Task '" + taskName + "' assigned to Team: " + teamId );
                } else {
                    System.out.println("Invalid Member ID. Please enter a valid Member ID.");
                }
            } else {
                System.out.println("Invalid Team ID. Please enter a valid Team ID.");
            }
        } else {
            System.out.println("Task with the specified name does not exist. Please enter a valid task name.");
        }
    }

    private void displayTeamMembersWithIds() {
        System.out.println("\nTeam Members with IDs:");
        System.out.println("+-------------------+-------------------+-------------------+");
        System.out.printf("| %-17s | %-17s | %-17s |%n", "Team Member Name", "Team ID", "Member ID");
        System.out.println("+-------------------+-------------------+-------------------+");

        for (TeamMember member : teamMembers) {
            System.out.printf("| %-17s | %-17s | %-17s |%n", member.getName(), member.getTeamId(), teamMembers.indexOf(member));
            System.out.println("+-------------------+-------------------+-------------------+");
        }
    }

    public void displayAllData() {
        System.out.println("\nAll Data:");
        displayTasks();
        displayTeamMembers();
    }

    private String getTeamNameById(String teamId) {
        for (TeamMember member : teamMembers) {
            if (member.getTeamId().equalsIgnoreCase(teamId)) {
                return member.getName();
            }
        }
        return "Not Assigned";
    }

    private List<String> getTeamMemberNamesById(String teamId) {
        List<String> teamMemberNames = new ArrayList<>();
        for (TeamMember member : teamMembers) {
            if (member.getTeamId().equalsIgnoreCase(teamId)) {
                teamMemberNames.add(member.getName());
            }
        }
        return teamMemberNames;
    }

    private Task findTaskByName(String taskName) {
        for (Task task : tasks) {
            if (task.getName().equalsIgnoreCase(taskName)) {
                return task;
            }
        }
        return null;
    }

    private boolean isTaskNameUnique(String taskName) {
        for (Task task : tasks) {
            if (task.getName().equalsIgnoreCase(taskName)) {
                return false;
            }
        }
        return true;
    }

    private boolean isTeamNameOrIdUnique(String teamNameOrId) {
        for (TeamMember member : teamMembers) {
            if (member.getTeamId().equalsIgnoreCase(teamNameOrId)) {
                return false;
            }
        }
        return true;
    }

    private boolean isTeamMemberNameUnique(String teamMemberName) {
        for (TeamMember member : teamMembers) {
            if (member.getName().equalsIgnoreCase(teamMemberName)) {
                return false;
            }
        }
        return true;
    }

    private boolean isTeamIdValid(String teamId) {
        for (TeamMember member : teamMembers) {
            if (member.getTeamId().equalsIgnoreCase(teamId)) {
                return true;
            }
        }
        return false;
    }

    private boolean isMemberIdValid(String memberId, String teamId) {
        try {
            int id = Integer.parseInt(memberId);
            if (id >= 0 && id < teamMembers.size() && teamMembers.get(id).getTeamId().equalsIgnoreCase(teamId)) {
                return true;
            }
        } catch (NumberFormatException | IndexOutOfBoundsException e) {
            // Ignore
        }
        return false;
    }

    public static void main(String[] args) {
        TaskManager taskManager = new TaskManager();
        Scanner scanner = new Scanner(System.in);

        while (true) {
            System.out.println("\nTask Management System");
            System.out.println("1. Add Task");
            System.out.println("2. Remove Task");
            System.out.println("3. Display Tasks");
            System.out.println("4. Add Team");
            System.out.println("5. Display Team Members");
            System.out.println("6. Assign Task to Team");
            System.out.println("7. Display All Data");
            System.out.println("8. Exit");
            System.out.print("Enter your choice: ");
            int choice;
            try {
                choice = scanner.nextInt();
            } catch (InputMismatchException e) {
                System.out.println("Invalid input. Please enter a number.");
                scanner.nextLine();
                continue;
            }

            switch (choice) {
                case 1:
                    System.out.print("Enter task name: ");
                    scanner.nextLine();
                    String taskName = scanner.nextLine();
                    if (taskManager.isTaskNameUnique(taskName)) {
                        System.out.print("Enter task description: ");
                        String taskDescription = scanner.nextLine();
                        taskManager.addTask(new Task(taskName, taskDescription));
                    } else {
                        System.out.println("Task with the same name already exists. Please choose a different name.");
                    }
                    break;
                case 2:
                    System.out.print("Enter task name to remove: ");
                    scanner.nextLine();
                    String taskToRemove = scanner.nextLine();
                    taskManager.removeTask(taskToRemove);
                    break;
                case 3:
                    taskManager.displayTasks();
                    break;
                case 4:
                    System.out.print("Enter team name or ID: ");
                    scanner.nextLine();
                    String teamNameOrId = scanner.nextLine();
                    if (taskManager.isTeamNameOrIdUnique(teamNameOrId)) {
                        System.out.print("Enter number of team members to add: ");
                        int numMembers;
                        try {
                            numMembers = scanner.nextInt();
                        } catch (InputMismatchException e) {
                            System.out.println("Invalid input. Please enter a number.");
                            scanner.nextLine();
                            continue;
                        }
                        taskManager.addTeam(teamNameOrId, numMembers);
                    } else {
                        System.out.println("Team with the same name or ID already exists. Please choose a different name or ID.");
                    }
                    break;
                case 5:
                    taskManager.displayTeamMembers();
                    break;
                case 6:
                    System.out.print("Enter task name to assign: ");
                    scanner.nextLine();
                    String taskNameToAssign = scanner.nextLine();
                    if (!taskManager.isTaskNameUnique(taskNameToAssign)) {
                        System.out.print("Enter team ID: ");
                        String teamId = scanner.nextLine();
                        if (taskManager.isTeamIdValid(teamId)) {
                            taskManager.assignTask(taskNameToAssign, teamId);
                        } else {
                            System.out.println("Invalid Team ID. Please enter a valid Team ID.");
                        }
                    } else {
                        System.out.println("Task with the specified name does not exist. Please enter a valid task name.");
                    }
                    break;
                case 7:
                    taskManager.displayAllData();
                    break;
                case 8:
                    System.out.println("Exiting Task Management System. Goodbye!");
                    scanner.close();
                    System.exit(0);
                default:
                    System.out.println("Invalid choice. Please select a valid option.");
            }
        }
    }
}